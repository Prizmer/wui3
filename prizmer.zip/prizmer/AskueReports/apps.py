from django.apps import AppConfig


class AskuereportsConfig(AppConfig):
    name = 'AskueReports'
