from django.apps import AppConfig


class PrizmerApiConfig(AppConfig):
    name = 'prizmer_api'
