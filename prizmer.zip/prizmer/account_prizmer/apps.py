from django.apps import AppConfig


class AccountPrizmerConfig(AppConfig):
    name = 'account_prizmer'
