-- ВЗЛЕТ ТСР-М ТСРВ-024М Энергия_1 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('ec6fc0ca-5f75-4ad7-96b2-e66aee490d7e', 'ВЗЛЕТ ТСР-М ТСРВ-024М Энергия_1 Суточный -- adress: 7  channel: 1', 7, 1, '009c284f-dffb-47a5-80ad-421f10569b8a', '30936305-66a6-4459-b7d0-9c3ea8e2ba12', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- ВЗЛЕТ ТСР-М ТСРВ-024М Энергия_2 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('c7d5aa55-10da-4075-bfa3-1b79ae924b1b', 'ВЗЛЕТ ТСР-М ТСРВ-024М Энергия_2 Суточный -- adress: 7  channel: 2', 7, 2, '5bb63f0e-4cf3-42d4-b62f-3fbcc1c9c20f', '30936305-66a6-4459-b7d0-9c3ea8e2ba12', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- ВЗЛЕТ ТСР-М ТСРВ-024М Энергия_3 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('39d45f5f-f758-48cc-b55f-97a534114ffc', 'ВЗЛЕТ ТСР-М ТСРВ-024М Энергия_3 Суточный -- adress: 7  channel: 3', 7, 3, '2f46ecbd-0089-4419-80bc-a92b8d207ebf', '30936305-66a6-4459-b7d0-9c3ea8e2ba12', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- ВЗЛЕТ ТСР-М ТСРВ-024М Масса_1 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('cae77cb0-740f-4f0f-973b-4699f5a353b6', 'ВЗЛЕТ ТСР-М ТСРВ-024М Масса_1 Суточный -- adress: 9  channel: 1', 9, 1, '15c66fb6-70cd-4649-9861-e9382314f45d', '30936305-66a6-4459-b7d0-9c3ea8e2ba12', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- ВЗЛЕТ ТСР-М ТСРВ-024М Масса_2 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('3044cce6-0653-4fd4-9384-159d570abd27', 'ВЗЛЕТ ТСР-М ТСРВ-024М Масса_2 Суточный -- adress: 9  channel: 2', 9, 2, '088d362f-689e-44bc-85c7-7a7b37ba87c7', '30936305-66a6-4459-b7d0-9c3ea8e2ba12', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- ВЗЛЕТ ТСР-М ТСРВ-024М Масса_3 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('ba655bde-5621-4da9-a642-7542e73550fa', 'ВЗЛЕТ ТСР-М ТСРВ-024М Масса_3 Суточный -- adress: 9  channel: 3', 9, 3, 'd8e48314-1d79-460b-b0ab-acfb20115507', '30936305-66a6-4459-b7d0-9c3ea8e2ba12', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- ВЗЛЕТ МР УРСВ-311 Объем_входящий Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('56aefad0-0058-4ee2-95fe-aaf02e54c4ca', 'ВЗЛЕТ МР УРСВ-311 Объем_входящий Суточный -- adress: 0  channel: 3', 0, 3, '736723cc-6be0-4e0b-95ce-d1194b8455fd', '4d85e9a5-513e-419c-a02e-3e6ba79eafa7', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
