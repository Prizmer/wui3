-- Добавляем имя параметра Энергия_1
INSERT INTO public.names_params(
	guid, name, guid_measurement, guid_resources)
	VALUES ('009c284f-dffb-47a5-80ad-421f10569b8a', 'Энергия_1', '36f4e249-8173-4c78-ab13-75868f2dd57f', 'c0491ede-e00b-4e1d-a8ba-1ef61dba1cd3');

-- Добавляем имя параметра Масса_1
INSERT INTO public.names_params(
	guid, name, guid_measurement, guid_resources)
	VALUES ('15c66fb6-70cd-4649-9861-e9382314f45d', 'Масса_1', '23b35f9b-a699-4bed-be1a-a28e3fd6d55d', 'c0491ede-e00b-4e1d-a8ba-1ef61dba1cd3');

-- Добавляем имя параметра Объем_входящий
INSERT INTO public.names_params(
	guid, name, guid_measurement, guid_resources)
	VALUES ('736723cc-6be0-4e0b-95ce-d1194b8455fd', 'Объем_входящий', 'c1ebaac1-5aca-4f3e-a560-5c2f67ab7c6e', '57ec8f42-69c6-4f79-81bb-8ea139407aa9');
