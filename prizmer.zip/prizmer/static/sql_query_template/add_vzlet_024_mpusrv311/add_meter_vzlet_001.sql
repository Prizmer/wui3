-- Добавляем тип прибора ВЗЛЕТ ТСР-М ТСРВ-024М
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('30936305-66a6-4459-b7d0-9c3ea8e2ba12', 'ВЗЛЕТ ТСР-М ТСРВ-024М', 'vzlet');

-- Добавляем тип прибора ВЗЛЕТ МР УРСВ-311
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('4d85e9a5-513e-419c-a02e-3e6ba79eafa7', 'ВЗЛЕТ МР УРСВ-311', 'vzlet');