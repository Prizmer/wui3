-- Добавляем тип прибора Нартис СПОДЭС
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('8790eaeb-671b-4596-b80e-d6475d74382c', 'Нартис СПОДЭС', 'nartis_spodes');