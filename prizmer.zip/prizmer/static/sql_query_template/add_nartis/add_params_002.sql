-- Нартис СПОДЭС T0 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('1b93aeca-461c-468a-a0b9-792bd89001ab', 'Нартис СПОДЭС T0 A+ Суточный -- adress: 0  channel: 0', 0, 0, '0e1b1524-e9d2-4585-a6ee-4c499bdf86e9', '8790eaeb-671b-4596-b80e-d6475d74382c', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Нартис СПОДЭС T1 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('634d9f9a-a7f2-479e-9904-147cfa800ccc', 'Нартис СПОДЭС T1 A+ Суточный -- adress: 0  channel: 1', 0, 1, 'a30f5530-c027-4d8a-815b-6abfb1d81028', '8790eaeb-671b-4596-b80e-d6475d74382c', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- Нартис СПОДЭС T2 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('949b3f73-a0bb-4037-8f13-cb30c815c226', 'Нартис СПОДЭС T2 A+ Суточный -- adress: 0  channel: 2', 0, 2, '6e822182-8dca-47f6-a25b-8599423f342e', '8790eaeb-671b-4596-b80e-d6475d74382c', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- Нартис СПОДЭС T3 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('14ba0cf1-d4c6-40d6-a70c-9ecdd2c73050', 'Нартис СПОДЭС T3 A+ Суточный -- adress: 0  channel: 3', 0, 3, '3aa0b0ca-d62d-497d-a9d5-5d2f7e2d4c67', '8790eaeb-671b-4596-b80e-d6475d74382c', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Нартис СПОДЭС T4 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('eac09f54-2365-4cc9-a4cc-cd375d3b5039', 'Нартис СПОДЭС T4 A+ Суточный -- adress: 0  channel: 4', 0, 4, '1d1d1038-2789-4fcf-a420-8be0ba20d99a', '8790eaeb-671b-4596-b80e-d6475d74382c', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Нартис СПОДЭС A+ Профиль
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('e9e1c90f-7b4a-4ba0-a51e-e8b7a0cfbb41', 'Нартис СПОДЭС A+ Профиль Получасовой -- adress: 0  channel: 5', 0, 5, '9ad9b931-fe2b-463d-b47f-f0a471279313', '8790eaeb-671b-4596-b80e-d6475d74382c', 'e78189b5-f9f9-4fdd-830e-5b98c342d7c1');
	
-- Нартис СПОДЭС R+ Профиль
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('4d8a4b75-695a-43e1-9a40-87c0e9f57e24', 'Нартис СПОДЭС R+ Профиль Получасовой -- adress: 0  channel: 6', 0, 6, '475ac5ee-3ddd-4311-a0fb-d4bf531cbafd', '8790eaeb-671b-4596-b80e-d6475d74382c', 'e78189b5-f9f9-4fdd-830e-5b98c342d7c1');