﻿INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('03d32edf-c9d8-4f49-ba11-e775c0c403f6',0,1,'a30f5530-c027-4d8a-815b-6abfb1d81028','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','bb986590-63cb-4b9f-8f4b-1b96335c5441','СЭТ-4ТМ.03М T1 A+ Суточный -- adress: 0  channel: 1')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('087b785e-5d59-4956-9cd3-57706f9557e6',1,0,'40e69bf7-fc3f-4a90-8264-988e819a2e9f','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','bb986590-63cb-4b9f-8f4b-1b96335c5441','СЭТ-4ТМ.03М T0 R+ Суточный -- adress: 1  channel: 0')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('3d365f91-8bd3-476e-b07e-3f79134f6853',1,0,'40e69bf7-fc3f-4a90-8264-988e819a2e9f','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','3b0d3f12-f92f-476d-96d3-e1d2c1a19e2f','СЭТ-4ТМ.03М T0 R+ Месячный -- adress: 1  channel: 0')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('4f505e17-7d71-4cf8-9880-c6ce33612e6e',0,0,'9ad9b931-fe2b-463d-b47f-f0a471279313','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','e78189b5-f9f9-4fdd-830e-5b98c342d7c1','СЭТ-4ТМ.03М A+ Профиль Получасовой -- adress: 0  channel: 0')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('55237552-8678-483e-8073-5d6c567371f4',0,2,'6e822182-8dca-47f6-a25b-8599423f342e','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','bb986590-63cb-4b9f-8f4b-1b96335c5441','СЭТ-4ТМ.03М T2 A+ Суточный -- adress: 0  channel: 2')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('55abd40d-fb3c-4100-88f2-46d79be7733a',2,0,'475ac5ee-3ddd-4311-a0fb-d4bf531cbafd','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','e78189b5-f9f9-4fdd-830e-5b98c342d7c1','СЭТ-4ТМ.03М R+ Профиль Получасовой -- adress: 2  channel: 0')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('aa83b499-6a9e-40e1-b68b-dc84fec8490b',0,0,'0e1b1524-e9d2-4585-a6ee-4c499bdf86e9','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','bb986590-63cb-4b9f-8f4b-1b96335c5441','СЭТ-4ТМ.03М T0 A+ Суточный -- adress: 0  channel: 0')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('e3db7e77-90a5-455f-96f5-7c257cb4ab76',0,3,'3aa0b0ca-d62d-497d-a9d5-5d2f7e2d4c67','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','bb986590-63cb-4b9f-8f4b-1b96335c5441','СЭТ-4ТМ.03М T3 A+ Суточный -- adress: 0  channel: 3')

INSERT INTO params(guid,param_address, channel,guid_names_params, guid_types_meters, guid_types_params, name )
    VALUES ('e7624c25-9852-4ffd-8777-b2bfd16c29a8',0,0,'0e1b1524-e9d2-4585-a6ee-4c499bdf86e9','66b7ce6a-f280-4e54-8c8d-f69f34aabdf9','3b0d3f12-f92f-476d-96d3-e1d2c1a19e2f','СЭТ-4ТМ.03М T0 A+ Месячный -- adress: 0  channel: 0')