-- Добавляем имя параметра Канал 17
INSERT INTO public.names_params(
	guid, name, guid_measurement, guid_resources)
	VALUES ('3c5923d1-8125-4af8-abf9-862e5b3b5439', 'Канал 17', 'c1ebaac1-5aca-4f3e-a560-5c2f67ab7c6e', '12574d66-2034-4c8e-8c8c-249757736858');
-- Добавляем имя параметра Канал 18
INSERT INTO public.names_params(
	guid, name, guid_measurement, guid_resources)
	VALUES ('76245cb6-f5c9-4fa8-8c24-a71f32cc3179', 'Канал 18', 'c1ebaac1-5aca-4f3e-a560-5c2f67ab7c6e', '12574d66-2034-4c8e-8c8c-249757736858');
-- Добавляем имя параметра Канал 19
INSERT INTO public.names_params(
	guid, name, guid_measurement, guid_resources)
	VALUES ('4ec1972e-65a7-42c7-ba41-982f79bf60bd', 'Канал 19', 'c1ebaac1-5aca-4f3e-a560-5c2f67ab7c6e', '12574d66-2034-4c8e-8c8c-249757736858');
-- Добавляем имя параметра Канал 20
INSERT INTO public.names_params(
	guid, name, guid_measurement, guid_resources)
	VALUES ('32e0ebca-2df4-45f8-807a-921f147210f0', 'Канал 20', 'c1ebaac1-5aca-4f3e-a560-5c2f67ab7c6e', '12574d66-2034-4c8e-8c8c-249757736858');