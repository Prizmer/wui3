-- Добавляем тип прибора регистратор импульсов МЗТА
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'МЗТА', 'mzta');