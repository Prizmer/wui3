-- МЗТА Канал 2 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('82ce9adf-0a2e-4ceb-8d95-89fc4d9df289', 'МЗТА Канал 2 Суточный -- adress: 2  channel: 0', 2, 0, 'd68113c9-0f5b-43bd-815c-2a66f304c8f6', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- МЗТА Канал 3 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('4fd62d3d-880f-4f00-81bd-41b380c012da', 'МЗТА Канал 3 Суточный -- adress: 3  channel: 0', 3, 0, '070e5074-1c09-4826-bbb7-39607ee6b6c8', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 4 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('ec10fc08-9e1b-416b-ab8e-b6f2233c8196', 'МЗТА Канал 4 Суточный -- adress: 4  channel: 0', 4, 0, 'aef66fe2-d8de-4697-874f-d91ef48386e4', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 5 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('12ea6b3b-4dcf-40e3-bdf1-9edb80b9585a', 'МЗТА Канал 5 Суточный -- adress: 5  channel: 0', 5, 0, '2fb7f1b6-dd14-4576-b66f-5bad98bea65d', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 6 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('6352996a-dc82-4939-8e0d-8679af9a3cb4', 'МЗТА Канал 6 Суточный -- adress: 6  channel: 0', 6, 0, '44d47679-97a0-4444-8f30-bd30d4861789', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 7 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('99c31bc4-0764-472a-91f9-774c7eacfaed', 'МЗТА Канал 7 Суточный -- adress: 7  channel: 0', 7, 0, 'fb97edae-10f5-4772-9a4e-73e2b0ab488b', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 8 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('f394d963-c94f-42ac-9a15-d83dd0a97e78', 'МЗТА Канал 8 Суточный -- adress: 8  channel: 0', 8, 0, '35ff522d-0d31-41a1-a9fd-a388a5cbf266', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 9 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('8f16a338-23db-4fe0-99e1-3aad34897fda', 'МЗТА Канал 9 Суточный -- adress: 9  channel: 0', 9, 0, 'af4b173b-8292-48c9-8f6a-e18061d75893', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 10 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('11136ad3-a88e-40e5-8d19-cbf43032d17c', 'МЗТА Канал 10 Суточный -- adress: 10  channel: 0', 10, 0, '02ce4681-7be0-47c9-acd4-67a6c8d439e9', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 11 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('41f7302d-4fe7-4b55-8cc4-5d12269671e1', 'МЗТА Канал 11 Суточный -- adress: 11  channel: 0', 11, 0, '21449962-b377-42bf-ac23-b1f4ae148df9', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 12 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('6472c355-66cd-4f99-8c17-a01ad155449e', 'МЗТА Канал 12 Суточный -- adress: 12  channel: 0', 12, 0, '9b457f63-51f9-491e-8a6f-1a9aa5ac2e62', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 13 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('5a4f437f-8b6d-4a59-9ec3-ad5f47cefccf', 'МЗТА Канал 13 Суточный -- adress: 13  channel: 0', 13, 0, '77c7effc-99b2-4e67-bad9-cef3f3ae47df', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 14 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('447cf2bb-bc43-4a50-8cd0-b1cc0407d973', 'МЗТА Канал 14 Суточный -- adress: 14  channel: 0', 14, 0, 'e0f6b50f-127d-4189-a376-3494d2afbdba', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 15 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('98bcdfdd-8965-42f3-84fe-978d367be9eb', 'МЗТА Канал 15 Суточный -- adress: 15  channel: 0', 15, 0, '37595211-23ea-49de-ba78-c529df6e577f', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 16 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('8663465e-64d1-49d9-915b-b0cd7d71a503', 'МЗТА Канал 16 Суточный -- adress: 16  channel: 0', 16, 0, '2e91f015-633d-4e7c-ad10-3cfd88e77aa6', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 17 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('f7af4d4f-e542-406d-9ad2-44a5b8e9d506', 'МЗТА Канал 17 Суточный -- adress: 17  channel: 0', 17, 0, '3c5923d1-8125-4af8-abf9-862e5b3b5439', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 18 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('ccd0c7f4-babd-4953-99c8-b6adf0cf1b12', 'МЗТА Канал 18 Суточный -- adress: 18  channel: 0', 18, 0, '76245cb6-f5c9-4fa8-8c24-a71f32cc3179', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 19 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('7633d6a2-9cba-49d4-b456-a51e137b45f1', 'МЗТА Канал 19 Суточный -- adress: 19  channel: 0', 19, 0, '4ec1972e-65a7-42c7-ba41-982f79bf60bd', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МЗТА Канал 20 Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('a556773c-888a-4bb7-8ac4-e083630f0f28', 'МЗТА Канал 20 Суточный -- adress: 20  channel: 0', 20, 0, '32e0ebca-2df4-45f8-807a-921f147210f0', '295f91bd-3e05-435e-9eb8-bda7eddaf6a4', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
