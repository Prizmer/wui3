-- Добавляем тип прибора Danfoss RTU
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('5e1dbf09-6c37-4982-aa1e-a693d2b4f079', 'SonoMeter-500', 'sonometer500');