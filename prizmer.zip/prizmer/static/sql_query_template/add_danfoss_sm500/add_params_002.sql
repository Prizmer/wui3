-- Danfoss SonoMeter-500 Энергия Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('751b8d48-b7f9-4b68-85a1-b1cb00e08dc2', 'Danfoss SonoMeter-500 Энергия Суточный -- adress: 7  channel: 1', 7, 1, '64f9b17d-d599-428d-8849-5db3d37c7b0e', '5e1dbf09-6c37-4982-aa1e-a693d2b4f079', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Danfoss SonoMeter-500 Объем Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('bad0b995-04ac-4650-ada1-9ddec3574606', 'Danfoss SonoMeter-500 Объем Суточный -- adress: 8  channel: 1', 8, 1, '092c67af-25ce-41ca-85ce-cb96953c930d', '5e1dbf09-6c37-4982-aa1e-a693d2b4f079', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Danfoss SonoMeter-500 Тin Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('bc847426-44cf-4788-8abf-8ec84e81fb5f', 'Danfoss SonoMeter-500 Ti Суточный -- adress: 3  channel: 1', 3, 1, 'bb56b908-a67d-48f3-95c5-4c8eec379056', '5e1dbf09-6c37-4982-aa1e-a693d2b4f079', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Danfoss SonoMeter-500 Tout Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('230e16d7-d4d1-4a31-86a9-c962791dd0e0', 'Danfoss SonoMeter-500 To Суточный -- adress: 4  channel: 1', 4, 1, '62bb153e-a48f-49c4-8628-39d0a3574aa4', '5e1dbf09-6c37-4982-aa1e-a693d2b4f079', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	