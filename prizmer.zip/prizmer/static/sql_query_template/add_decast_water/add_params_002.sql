-- Декаст ХВС Объем ХВС Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('2c129d66-9551-43af-b841-3beeb31974e1', 'Декаст ХВС Объем ХВС Суточный -- adress: 1  channel: 1', 1, 1, 'a49db310-391f-4479-b57d-aa7ac84dc2d8', '657d8ad0-bdba-4459-a07e-4d4eb72950d6', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Декаст ГВС Объем ГВС Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('a2df1925-fa6a-4e41-9ded-01f17f8db55d', 'Декаст ГВС Объем ГВС Суточный -- adress: 1  channel: 1', 1, 1, '1068fe5c-6de1-455e-8700-abd5ce98039c', '36b6ea95-beb1-490d-a39f-06163bfcaae5', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	