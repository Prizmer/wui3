-- Добавляем тип прибора Декаст ХВС
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('657d8ad0-bdba-4459-a07e-4d4eb72950d6', 'Декаст ХВС', 'decast');

-- Добавляем тип прибора Декаст ГВС
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('36b6ea95-beb1-490d-a39f-06163bfcaae5', 'Декаст ГВС', 'decast');