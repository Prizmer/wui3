﻿SELECT 
  tcpip_settings.guid, 
  tcpip_settings.ip_address, 
  tcpip_settings.ip_port
FROM 
  public.tcpip_settings;
