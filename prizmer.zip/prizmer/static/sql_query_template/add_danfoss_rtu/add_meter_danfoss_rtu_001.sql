-- Добавляем тип прибора Danfoss RTU
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('9e7353a7-3bd3-4176-9a35-d152dcfcb74c', 'Danfoss RTU', 'danfoss');