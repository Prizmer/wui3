-- МИРТЕК-32-РУ-D37 T0 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('5ec99a35-51ef-4d93-b0c3-4da0667339e9', 'МИРТЕК-32-РУ-D37 T0 A+ Суточный -- adress: 0  channel: 0', 0, 0, '0e1b1524-e9d2-4585-a6ee-4c499bdf86e9', '2d99741f-b22e-4926-af61-056e956b24b0', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- МИРТЕК-32-РУ-D37 T1 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('88810096-9bfb-4190-b82c-e1d29e19152d', 'МИРТЕК-32-РУ-D37 T1 A+ Суточный -- adress: 0  channel: 1', 0, 1, 'a30f5530-c027-4d8a-815b-6abfb1d81028', '2d99741f-b22e-4926-af61-056e956b24b0', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МИРТЕК-32-РУ-D37 T2 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('8f51964e-2652-4956-9396-17cd9e243068', 'МИРТЕК-32-РУ-D37 T2 A+ Суточный -- adress: 0  channel: 2', 0, 2, '6e822182-8dca-47f6-a25b-8599423f342e', '2d99741f-b22e-4926-af61-056e956b24b0', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');

-- МИРТЕК-32-РУ-D37 T3 A+ Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('84c7b310-1608-4fb2-89ff-a93ed00cb862', 'МИРТЕК-32-РУ-D37 T3 A+ Суточный -- adress: 0  channel: 3', 0, 3, '3aa0b0ca-d62d-497d-a9d5-5d2f7e2d4c67', '2d99741f-b22e-4926-af61-056e956b24b0', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
