-- Добавляем тип прибора МИРТЕК-32-РУ-D37
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('2d99741f-b22e-4926-af61-056e956b24b0', '', 'mirtek');