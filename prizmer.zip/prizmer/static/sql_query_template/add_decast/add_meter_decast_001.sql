-- Добавляем тип прибора Декаст Теплосчётчик
INSERT INTO public.types_meters(
	guid, name, driver_name)
	VALUES ('b95134db-af0c-4eea-bc8e-32b2bcfc7e1d', 'Декаст Теплосчётчик', 'decast');