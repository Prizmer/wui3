-- Декаст Энергия Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('7b109795-7076-444c-ba75-0f6494e523c5', 'Декаст Теплосчётчик Энергия Суточный -- adress: 7  channel: 1', 7, 1, '64f9b17d-d599-428d-8849-5db3d37c7b0e', 'b95134db-af0c-4eea-bc8e-32b2bcfc7e1d', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Декаст Объем Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('99fd51ba-2b1a-4cd3-adde-e0e744250d96', 'Декаст Теплосчётчик Объем Суточный -- adress: 8  channel: 1', 8, 1, '092c67af-25ce-41ca-85ce-cb96953c930d', 'b95134db-af0c-4eea-bc8e-32b2bcfc7e1d', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Декаст Тin Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('47c98a3e-0db8-4c51-8f2e-a4eed31039f9', 'Декаст Теплосчётчик Ti Суточный -- adress: 3  channel: 1', 3, 1, 'bb56b908-a67d-48f3-95c5-4c8eec379056', 'b95134db-af0c-4eea-bc8e-32b2bcfc7e1d', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	
-- Декаст Tout Суточный
INSERT INTO public.params(
	guid, name, param_address, channel, guid_names_params, guid_types_meters, guid_types_params)
	VALUES ('9a0c606e-6986-4a36-93a4-0769a2f851e9', 'Декаст Теплосчётчик To Суточный -- adress: 4  channel: 1', 4, 1, '62bb153e-a48f-49c4-8628-39d0a3574aa4', 'b95134db-af0c-4eea-bc8e-32b2bcfc7e1d', 'bb986590-63cb-4b9f-8f4b-1b96335c5441');
	