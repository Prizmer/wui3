UPDATE public.meters
	SET attr1='Стояк 1'
	WHERE name like '%Пульсар%M%'