﻿UPDATE abonents
   SET account_1=substring(name from 10)

  where name like '%Квартира%'
