﻿
    
INSERT INTO params(
            guid, param_address, channel, guid_names_params, guid_types_meters, 
            guid_types_params, name)
    VALUES ('3024fd72-d1e8-4476-a876-4bc09553dde9', '16', '0', '092c67af-25ce-41ca-85ce-cb96953c930d', '84fb7a85-ab91-4e93-9154-76ddee35a316', 'bb986590-63cb-4b9f-8f4b-1b96335c5441', 'Карат 307 Объем Суточный -- adress: 16  channel: 0'),
   ('46a63ef5-5761-4e16-a854-1979ddc9668f', '80', '0', 'b33393b2-78aa-4921-a548-d603ec8ca4cc', '84fb7a85-ab91-4e93-9154-76ddee35a316', 'bb986590-63cb-4b9f-8f4b-1b96335c5441', 'Карат 307 Q Система1 Суточный -- adress: 80  channel: 0'),
    ('6dd6ea63-20dc-46d0-b56e-6890a2b83f48', '49', '0', '62bb153e-a48f-49c4-8628-39d0a3574aa4', '84fb7a85-ab91-4e93-9154-76ddee35a316', 'bb986590-63cb-4b9f-8f4b-1b96335c5441', 'Карат 307 To Суточный -- adress: 49  channel: 0'),
    ('8a5f5921-5b70-410d-83de-8403ec2a4d87', '48', '0', 'bb56b908-a67d-48f3-95c5-4c8eec379056', '84fb7a85-ab91-4e93-9154-76ddee35a316', 'bb986590-63cb-4b9f-8f4b-1b96335c5441', 'Карат 307 Ti Суточный -- adress: 48  channel: 0'),
    ('9c86e183-dd53-4c7f-b728-ffe75a55c633', '176', '0', 'd39cfb10-e89e-437d-b9f7-6fcf65abcc56', '84fb7a85-ab91-4e93-9154-76ddee35a316', 'bb986590-63cb-4b9f-8f4b-1b96335c5441', 'Карат 307 Ton Суточный -- adress: 176  channel: 0'),
    ('abd41546-02f6-4e2c-8bd2-a60ab80ffe66', '212', '0', '2a94de53-4e56-43bf-ab2d-9b7b3358eb08', '84fb7a85-ab91-4e93-9154-76ddee35a316', 'bb986590-63cb-4b9f-8f4b-1b96335c5441', 'Карат 307 Terr Суточный -- adress: 212  channel: 0'),
  ('eb617f04-14a3-403c-90e8-286412872232', '32', '0', '7a72d894-11fe-45ea-9e51-52711c01adf2', '84fb7a85-ab91-4e93-9154-76ddee35a316', 'bb986590-63cb-4b9f-8f4b-1b96335c5441', 'Карат 307 M Система1 Суточный -- adress: 32  channel: 0')
