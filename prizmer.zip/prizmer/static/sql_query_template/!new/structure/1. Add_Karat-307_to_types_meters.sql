﻿INSERT INTO types_meters(
            guid, name, driver_name)
    VALUES ('84fb7a85-ab91-4e93-9154-76ddee35a316', 'Карат 307', 'karat_23X');
