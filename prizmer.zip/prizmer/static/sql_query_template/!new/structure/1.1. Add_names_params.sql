﻿INSERT INTO names_params(
            guid, name, guid_measurement, guid_resources)
    VALUES ('d39cfb10-e89e-437d-b9f7-6fcf65abcc56', 'Ton', 'a9cf9822-3465-4de7-8ff8-10c0395ee29b', 'c0491ede-e00b-4e1d-a8ba-1ef61dba1cd3'),
    ('2a94de53-4e56-43bf-ab2d-9b7b3358eb08','Terr','a9cf9822-3465-4de7-8ff8-10c0395ee29b','c0491ede-e00b-4e1d-a8ba-1ef61dba1cd3')
