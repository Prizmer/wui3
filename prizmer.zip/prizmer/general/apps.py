from django.apps import AppConfig


class GeneralConfig(AppConfig):
    name = 'general'
